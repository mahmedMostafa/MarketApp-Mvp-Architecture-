package com.example.market;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    private TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //this is to delete the line between the toolBar and the Tab Layout
        ActionBar toolbar = getSupportActionBar();
        toolbar.setElevation(0);
        //setting up the tab layout
        setUpTabLayout();
    }

    private void setUpTabLayout(){
        //find the custom view pager we created which doesn't allow the user to swipe among tabs
        ViewPager viewPager =(CustomViewPager) findViewById(R.id.view_pager);
        ((CustomViewPager) viewPager).setEnableSwipe(false);
        //create an adapter that knows which fragment should show in each tab
        SimpleFragmentPagerAdapter adapter = new SimpleFragmentPagerAdapter(getSupportFragmentManager());
        //set the adapter into the view pager
        viewPager.setAdapter(adapter);
        //give the tab layout the view pager
        tabLayout = findViewById(R.id.sliding_tabs);
        tabLayout.setupWithViewPager(viewPager);
        //setting the icons into the tabs
        SimpleFragmentPagerAdapter.setupTabsIcons(tabLayout,this);
    }
}

