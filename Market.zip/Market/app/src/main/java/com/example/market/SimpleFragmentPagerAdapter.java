package com.example.market;

import android.content.Context;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.view.LayoutInflater;
import android.widget.TextView;

public class SimpleFragmentPagerAdapter extends FragmentPagerAdapter {

    public SimpleFragmentPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    //return the corresponding fragment
    @Override
    public Fragment getItem(int i) {
        Fragment currentFragment = null;
        switch (i) {
            case 0:
                currentFragment = new HomeFragment();
                break;
            case 1:
                currentFragment = new FavoritesFragment();
                break;
            case 2:
                currentFragment = new CartFragment();
                break;
            default:
                currentFragment = new HomeFragment();
        }
        return currentFragment;
    }

    //we return the number of tabs (starting from 1)
    @Override
    public int getCount() {
        return 3;
    }

    //setting the icons and the titles for the tabs
    public static void setupTabsIcons(TabLayout layout, Context context){
        TextView tabOne = (TextView) LayoutInflater.from(context).inflate(R.layout.custom_tab, null);
        tabOne.setText("Home");
        tabOne.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_home, 0, 0);
        layout.getTabAt(0).setCustomView(tabOne);
        TextView tabTwo = (TextView) LayoutInflater.from(context).inflate(R.layout.custom_tab, null);
        tabTwo.setText("Saved");
        tabTwo.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_favorite, 0, 0);
        layout.getTabAt(1).setCustomView(tabTwo);

        TextView tabThree = (TextView) LayoutInflater.from(context).inflate(R.layout.custom_tab, null);
        tabThree.setText("Cart");
        tabThree.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_drafts, 0, 0);
        layout.getTabAt(2).setCustomView(tabThree);
    }
}
